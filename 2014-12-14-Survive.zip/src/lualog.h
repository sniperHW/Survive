#ifndef _LUALOG_H
#define _LUALOG_H
#include "kendynet.h"
#include "log.h"
#include "lua_util.h"

void reg_lualog(lua_State *L);

#endif
