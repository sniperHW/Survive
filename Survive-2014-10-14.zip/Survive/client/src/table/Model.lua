Model = Model or { 
[1] = { ["Resource_Path"] = "animation/player/cat_m.c3b", ["Scale"] = 0.20000000, ["Standby"] = 101, ["Attack1"] = 103, ["Attack2"] = 104, ["Attack3"] = 105, ["Walk"] = 102, ["Hit"] = 106, ["Death"] = 107},
[101] = { ["Resource_Path"] = "animation/monster/gouxiong.plist", ["Standby"] = 1, ["Attack1"] = 3, ["Attack2"] = 6, ["Walk"] = 2, ["Hit"] = 4, ["Death"] = 5},
[102] = { ["Resource_Path"] = "animation/monster/gouxiongB.plist", ["Standby"] = 21, ["Attack1"] = 23, ["Attack2"] = 26, ["Walk"] = 22, ["Hit"] = 24, ["Death"] = 25},
[103] = { ["Resource_Path"] = "animation/monster/lang.plist", ["Standby"] = 41, ["Attack1"] = 43, ["Attack2"] = 46, ["Walk"] = 42, ["Hit"] = 44, ["Death"] = 45},
[104] = { ["Resource_Path"] = "animation/monster/konglong.plist", ["Standby"] = 61, ["Attack1"] = 63, ["Walk"] = 62, ["Hit"] = 64, ["Death"] = 65},
[105] = { ["Resource_Path"] = "animation/monster/yezhu.plist", ["Standby"] = 81, ["Attack1"] = 83, ["Walk"] = 82, ["Hit"] = 84, ["Death"] = 85}
}