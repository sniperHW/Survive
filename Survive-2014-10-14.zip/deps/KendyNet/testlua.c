#include "lua_util.h"

		
int main(){
	lua_State *L = luaL_newstate();
	luaL_openlibs(L);
	if (luaL_dofile(L,"test.lua")) {
		const char * error = lua_tostring(L, -1);
		lua_pop(L,1);
		printf("%s\n",error);
	}
	const char *err;
	
	err = LuaCall(L,"fun0",NULL);
	if(err) printf("error on fun0:%s\n",err);
	
	int iret1;
	err = LuaCall(L,"fun1","i:i",100,&iret1);
	if(err) printf("error on fun1:%s\n",err);
	else printf("ret1=%d\n",iret1);
	
	char *sret1;
	err = LuaCall(L,"fun2","ss:s","hello","kenny",&sret1);
	if(err) printf("error on fun2:%s\n",err);
	else printf("sret1=%s\n",sret1);
	
	char  *Sret1,*Sret2;
	size_t Lret1,Lret2;
	err = LuaCall(L,"fun3","ssS:SS","1","2","3",sizeof("3"),&Sret1,&Lret1,&Sret2,&Lret2);
	if(err) printf("error on fun3:%s\n",err); 
	else{
		printf("%s %d\n",Sret1,Lret1);
		printf("%s %d\n",Sret2,Lret2);		
	}
	
	
	luaRef_t funRef;
	err = LuaCall(L,"fun5",":r",&funRef);
	if(err) printf("error on fun5:%s\n",err);
	LuaCallRefFunc(funRef,NULL);	
	
	
	luaRef_t tabRef;
	int num;
	err = LuaCall(L,"fun6",":ri",&tabRef,&num);
	if(err) printf("error on fun6:%s\n",err);
	printf("%d\n",num);
	err = LuaCallTabFuncS(tabRef,"hello",NULL);
	if(err) printf("%s\n",err);
	
	
	err = LuaRef_Set(tabRef,"ss:is","f1",99,"f2","hello haha");
	if(err) printf("%s\n",err);
	else{
		int f1;
		const char *f2;
		err = LuaRef_Get(tabRef,"ss:is","f1",&f1,"f2",&f2);
		if(err) printf("%s\n",err);
		else printf("%d,%s\n",f1,f2);
	}
	return 0;	
}


/*
int main(){
	lua_State *L = luaL_newstate();
	luaL_openlibs(L);
	if (luaL_dofile(L,"test.lua")) {
		const char * error = lua_tostring(L, -1);
		lua_pop(L,1);
		printf("%s\n",error);
	}
	printf("--------test call lua function--------------\n");
	const char *err;
	if((err = LuaCall0(L,"fun0",0))){
		printf("lua error0:%s\n",err);
	}
	if((err = LuaCall1(L,"fun1",0,
					   lua_pushnumber(L,1)
	))){
		printf("lua error1:%s\n",err);
	}
	if((err = LuaCall2(L,"fun2",0,
					   lua_pushnumber(L,1),
					   lua_pushnumber(L,2)
	))){
		printf("lua error2:%s\n",err);
	}
	if((err = LuaCall3(L,"fun3",0,
					   lua_pushnumber(L,1),
					   lua_pushnumber(L,2),
					   lua_pushnumber(L,3)
	))){
		printf("lua error3:%s\n",err);
	}	
	if((err = LuaCall4(L,"fun4",0,
					   lua_pushnumber(L,1),
					   lua_pushnumber(L,2),
					   lua_pushnumber(L,3),
					   lua_pushnumber(L,4)					   
	
	))){
		printf("lua error4:%s\n",err);
	}	
	printf("--------------test call lua table function----------------------\n");	
	lua_getglobal(L,"ttab");
	luaTabRef_t tabRef = create_luaTabRef(L,-1);
	
	if((err = CallLuaTabFunc0(NULL,tabRef,"fun0",0))){
		printf("lua error0:%s\n",err);
	}
	if((err = CallLuaTabFunc1(NULL,tabRef,"fun1",0,
					   lua_pushnumber(L,1)
	))){
		printf("lua error1:%s\n",err);
	}
	if((err = CallLuaTabFunc2(NULL,tabRef,"fun2",0,
					   lua_pushnumber(L,1),
					   lua_pushnumber(L,2)
	))){
		printf("lua error2:%s\n",err);
	}
	if((err = CallLuaTabFunc3(NULL,tabRef,"fun3",0,
					   lua_pushnumber(L,1),
					   lua_pushnumber(L,2),
					   lua_pushnumber(L,3)
	))){
		printf("lua error3:%s\n",err);
	}	
	if((err = CallLuaTabFunc4(NULL,tabRef,"fun4",0,
					   lua_pushnumber(L,1),
					   lua_pushnumber(L,2),
					   lua_pushnumber(L,3),
					   lua_pushnumber(L,4)					   
	
	))){
		printf("lua error4:%s\n",err);
	}	
	if((err = CallLuaTabFunc0(NULL,tabRef,"none",0))){
		printf("call none:%s\n",err);
	}	
	
	release_luaTabRef(&tabRef);
	
	printf("------------test enum lua table-----------\n");	
	lua_getglobal(L,"ttab2");
	tabRef = create_luaTabRef(L,-1);
	LuaTabEnum(tabRef){
		lua_State *L = tabRef.L;
		printf("%s",lua_tostring(L,EnumKey));
		luaTabRef_t subtabRef = create_luaTabRef(L,EnumVal);
		LuaTabEnum(subtabRef){
			printf(",");
			printf("%d",(int)lua_tonumber(L,EnumVal));
		}
		printf("\n");
	}
	release_luaTabRef(&tabRef);
	
	printf("------------test get luaTabRef field-------\n");
	lua_getglobal(L,"ttab3");
	tabRef = create_luaTabRef(L,-1);
	const char *ip = LuaTabRefGet(tabRef,"ip",const char *,lua_tostring);
	int   port = LuaTabRefGet(tabRef,"port",int,lua_tointeger);
	printf("%s:%d\n",ip,port);
	release_luaTabRef(&tabRef);
	
	printf("------------test luaFuncRef----------------\n");
	lua_getglobal(L,"fun0");	
	luaFuncRef_t funcRef = create_luaFuncRef(L,-1);
	if((err = CallLuaFuncRef0(NULL,funcRef,0))){
		printf("lua error0:%s\n",err);
	}	
	release_luaFuncRef(&funcRef);												
	
	lua_getglobal(L,"fun1");	
	funcRef = create_luaFuncRef(L,-1);
	if((err = CallLuaFuncRef1(NULL,funcRef,0,
							  lua_pushnumber(L,1)	
	))){
		printf("lua error1:%s\n",err);
	}	
	release_luaFuncRef(&funcRef);
	
	lua_getglobal(L,"fun2");	
	funcRef = create_luaFuncRef(L,-1);
	if((err = CallLuaFuncRef2(NULL,funcRef,0,
							  lua_pushnumber(L,1),
							  lua_pushnumber(L,2)	
	))){
		printf("lua error2:%s\n",err);
	}	
	release_luaFuncRef(&funcRef);
	
	lua_getglobal(L,"fun3");	
	funcRef = create_luaFuncRef(L,-1);
	if((err = CallLuaFuncRef3(NULL,funcRef,0,
							  lua_pushnumber(L,1),
							  lua_pushnumber(L,2),
							  lua_pushnumber(L,3)	
	))){
		printf("lua error3:%s\n",err);
	}	
	release_luaFuncRef(&funcRef);
	
	
	lua_getglobal(L,"fun4");	
	funcRef = create_luaFuncRef(L,-1);
	if((err = CallLuaFuncRef4(NULL,funcRef,0,
							  lua_pushnumber(L,1),
							  lua_pushnumber(L,2),
							  lua_pushnumber(L,3),
							  lua_pushnumber(L,4)	
	))){
		printf("lua error4:%s\n",err);
	}	
	release_luaFuncRef(&funcRef);
	
	//pass to lua
	lua_getglobal(L,"fun4");	
	funcRef = create_luaFuncRef(L,-1);	
	lua_pop(L,1);//pop the function
	
	if((err = LuaCall1(L,"callFuncRef",0,PushLuaFuncRef(L,funcRef)))){
		printf("lua callFuncRef:%s\n",err);
	}
					
	
	return 0;
}*/
