print(args[1])
print(args[2])
print(args[3])
