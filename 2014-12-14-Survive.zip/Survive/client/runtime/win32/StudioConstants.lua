ccs = ccs or {}


ccs.MovementEventType = {
    start = 0,
    complete = 1,
    loopComplete = 2, 
}
