#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "buffer.h"

uint32_t buffer_count = 0;


