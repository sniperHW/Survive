#ifndef _LUAREDIS_H
#define _LUAREDIS_H
#include "kendynet.h"
#include "kn_redis.h"
#include "lua_util.h"

void reg_luaredis(lua_State *L);

#endif
